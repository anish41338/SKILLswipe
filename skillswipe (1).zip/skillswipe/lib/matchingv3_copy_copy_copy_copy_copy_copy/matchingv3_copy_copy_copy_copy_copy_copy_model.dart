import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'matchingv3_copy_copy_copy_copy_copy_copy_widget.dart'
    show Matchingv3CopyCopyCopyCopyCopyCopyWidget;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Matchingv3CopyCopyCopyCopyCopyCopyModel
    extends FlutterFlowModel<Matchingv3CopyCopyCopyCopyCopyCopyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
