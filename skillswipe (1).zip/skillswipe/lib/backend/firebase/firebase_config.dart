import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBDf418W1TnaZywuqTuSnIW4CeyX1HsZO0",
            authDomain: "skillswipe-rz60rc.firebaseapp.com",
            projectId: "skillswipe-rz60rc",
            storageBucket: "skillswipe-rz60rc.firebasestorage.app",
            messagingSenderId: "811693690731",
            appId: "1:811693690731:web:c9da8ed9df4bc2362e062e",
            measurementId: "G-SLVZ50P33B"));
  } else {
    await Firebase.initializeApp();
  }
}
