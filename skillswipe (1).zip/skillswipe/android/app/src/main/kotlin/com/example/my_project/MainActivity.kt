package com.mycompany.skillswipe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
